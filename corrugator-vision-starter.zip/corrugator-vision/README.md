# Corrugator Vision

A Streamlit + OpenCV prototype for image-based inspection and early-stage starter-point detection experiments.

## Features
- Upload a still image or start with a built-in synthetic test image
- Canny edge detection
- Binary threshold segmentation
- Contour inspection with bounding boxes and area labels
- Adjustable thresholds and minimum contour area
- Basic inspection summary

## Run locally
Python 3.10–3.12 recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Deploy as a live website
1. Push this folder to a GitHub repository.
2. Sign in to Streamlit Community Cloud.
3. Create a new app, select the repository and branch, and set the main file to `app.py`.
4. Deploy. Streamlit will install dependencies from `requirements.txt`.

## Safety
This is a still-image prototype. It does not connect to a production camera, PLC, actuator, or machine. Do not use its output to control equipment. Any future integration requires engineering validation, a machine risk assessment, and approved safety controls.
