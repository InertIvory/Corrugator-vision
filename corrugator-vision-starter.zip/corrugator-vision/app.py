import streamlit as st
import cv2
import numpy as np
from PIL import Image
from io import BytesIO

st.set_page_config(
    page_title="Corrugator Vision",
    page_icon="⚙️",
    layout="wide",
)

st.markdown("""
<style>
.block-container {padding-top: 1.6rem; max-width: 1200px;}
.metric-card {padding: 1rem; border: 1px solid rgba(128,128,128,.25); border-radius: 12px;}
.small-muted {color: #8b929b; font-size: .9rem;}
</style>
""", unsafe_allow_html=True)

st.title("⚙️ Corrugator Vision")
st.caption("Computer-vision workbench · Prototype for visual inspection and starter-point detection")

with st.sidebar:
    st.header("Detection settings")
    mode = st.selectbox(
        "Processing mode",
        ["Edge detection", "Threshold segmentation", "Contour inspection"]
    )
    low = st.slider("Canny lower threshold", 0, 255, 60)
    high = st.slider("Canny upper threshold", 0, 255, 150)
    threshold = st.slider("Binary threshold", 0, 255, 120)
    min_area = st.number_input("Minimum contour area (px²)", min_value=0, max_value=2_000_000, value=250, step=50)
    st.divider()
    st.info("Prototype only. It does not connect to a machine, PLC, camera stream, or actuator.")

left, right = st.columns([1, 1], gap="large")
with left:
    st.subheader("1 · Input image")
    uploaded = st.file_uploader("Upload a machine image", type=["png", "jpg", "jpeg", "bmp"])
    st.caption("Use a still image from a safe test setup. Avoid uploading confidential production images.")

    if uploaded is not None:
        try:
            pil_image = Image.open(uploaded).convert("RGB")
            rgb = np.array(pil_image)
        except Exception:
            st.error("The uploaded file could not be read as an image.")
            st.stop()
    else:
        # Synthetic test image so the app is useful on first launch.
        rgb = np.full((420, 640, 3), 238, dtype=np.uint8)
        cv2.rectangle(rgb, (70, 70), (570, 350), (190, 195, 200), -1)
        cv2.rectangle(rgb, (100, 105), (540, 315), (70, 78, 86), 3)
        cv2.line(rgb, (120, 210), (520, 210), (30, 30, 30), 5)
        cv2.circle(rgb, (320, 210), 22, (20, 145, 210), -1)
        cv2.putText(rgb, "SYNTHETIC TEST IMAGE", (125, 390), cv2.FONT_HERSHEY_SIMPLEX, .8, (70, 70, 70), 2)
        st.caption("Showing a synthetic test image. Upload a real image to test your own setup.")

    st.image(rgb, caption="Input", use_container_width=True)

gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
edges = cv2.Canny(gray, low, high)
_, binary = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
contours, _ = cv2.findContours(binary.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
valid = [c for c in contours if cv2.contourArea(c) >= min_area]
annotated = rgb.copy()

for contour in valid:
    x, y, w, h = cv2.boundingRect(contour)
    cv2.rectangle(annotated, (x, y), (x+w, y+h), (30, 180, 90), 2)
    cv2.putText(annotated, f"{int(cv2.contourArea(contour))} px2", (x, max(20, y-7)),
                cv2.FONT_HERSHEY_SIMPLEX, .45, (20, 120, 60), 1)

if mode == "Edge detection":
    output = edges
    output_caption = "Canny edges"
elif mode == "Threshold segmentation":
    output = binary
    output_caption = "Binary threshold"
else:
    output = annotated
    output_caption = "Contours above minimum area"

with right:
    st.subheader("2 · Processed output")
    if output.ndim == 2:
        st.image(output, caption=output_caption, clamp=True, use_container_width=True)
    else:
        st.image(output, caption=output_caption, use_container_width=True)

st.subheader("3 · Inspection summary")
m1, m2, m3 = st.columns(3)
m1.metric("Image size", f"{rgb.shape[1]} × {rgb.shape[0]}")
m2.metric("Contours detected", str(len(contours)))
m3.metric("Contours above minimum area", str(len(valid)))

if valid:
    largest = max(valid, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(largest)
    st.write(f"**Largest candidate region:** x={x}, y={y}, width={w}, height={h}, area={int(cv2.contourArea(largest))} px²")
else:
    st.write("No contours met the minimum-area setting. Try lowering the minimum area or changing the threshold.")

st.divider()
st.subheader("Next engineering steps")
st.markdown("""
- **Camera input:** replace image upload with a camera stream on a dedicated test computer.
- **Starter-point detection:** collect labelled examples, define a region of interest, and test a repeatable detection rule.
- **Calibration:** map image coordinates to real-world coordinates using a measured calibration target.
- **PLC integration:** add a separately tested, permissioned interface only after validation and a machine risk assessment.
""")
st.warning("Safety boundary: this demo only analyses still images. Do not use its output to trigger machinery. Validate detection performance and use approved machine-safety controls before any real-world integration.")
